# Timber Mitten Co.

## Structure
- `public/` — the static site (index.html plus a few standalone pages). This is what gets served to visitors.
- `api/` — a small Express server that replaces the old Netlify Functions (order/upload email notifications, optional background removal). This runs continuously as a Render "Web Service," not per-request like Netlify's functions did.
- `render.yaml` — a Render Blueprint that can create both services at once. Written from documented Render syntax but not verified against a live Render account — if it fails to parse, create the two services manually in Render's dashboard instead (New > Static Site for `public/`, New > Web Service for `api/`).

## First-time setup

1. **Push this repo to GitHub.**
2. **In Render:** New > Blueprint, point it at this repo. If that fails, create manually:
   - **Static Site**: root directory `public`, no build command.
   - **Web Service**: root directory `api`, build command `npm install`, start command `npm start`.
3. **Set environment variables** on the API service (Render dashboard > Environment):
   - `RESEND_API_KEY` — from resend.com
   - `REMOVE_BG_API_KEY` — optional, only if you turn on background removal
   - `ALLOWED_ORIGIN` — the exact URL of your deployed static site
4. **After both are live**, Render will show you their real `*.onrender.com` URLs. Update:
   - `ALLOWED_ORIGIN` on the API service to match the static site's real URL
   - `API_BASE` near the top of `public/index.html`'s `<script>` block to match the API's real URL
5. Redeploy, then place a real test order and confirm the email actually arrives before advertising again.
